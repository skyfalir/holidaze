import { apiUrl } from '../apiConstants';
import localStorageHandling from '../localStorageHandling';

const getVenueData = async ( id = '', filters) => {
  try {
    let endpoint = '/venues';
    if (id) {
      endpoint += `/${id}?_bookings=true`;
    } else if (filters.sortField && filters.sortOrder) {
      const {sortField, sortOrder} = filters;
      const sortQuery = `?limit=10&sort=${sortField}&sortOrder=${sortOrder}&_bookings=true`;

      endpoint += sortQuery;
    } else {
      endpoint += `?limit=10`; // Default query when no filters are provided
    }

    const userData = localStorageHandling.getUserData();
    const accessToken = userData.accessToken;

    const response = await fetch(apiUrl + endpoint, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });
    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error fetching venue:', error);
    return null;
  }
};

export default getVenueData;