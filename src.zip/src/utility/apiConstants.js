export const apiUrl = 'https://api.noroff.dev/api/v1/holidaze';
export const registerUrl = '/auth/register';
export const loginUrl = '/auth/login';
