import React, { useState } from 'react';
import './createvenue.css';

const CreateVenueForm = () => {
	const [formData, setFormData] = useState({
		name: '',
		description: '',
		media: [],
		price: 0,
		maxGuests: 0,
		rating: 0,
		meta: {
			wifi: false,
			parking: false,
			breakfast: false,
			pets: false,
		},
		location: {
			address: 'Unknown',
			city: 'Unknown',
			zip: 'Unknown',
			country: 'Unknown',
			continent: 'Unknown',
			lat: 0,
			lng: 0,
		},
	});

	const handleInputChange = (e) => {
		const { name, value } = e.target;
		setFormData((prevData) => ({
			...prevData,
			[name]: value,
		}));
	};

	const handleSubmit = (e) => {
		e.preventDefault();
		// Handle form submission, e.g., send data to the server
		console.log('Form submitted:', formData);
	};

	return (
		<form className="create-venue-form" onSubmit={handleSubmit}>
			<div className="form-group">
				<label htmlFor="name">Name:</label>
				<input
					type="text"
					id="name"
					name="name"
					value={formData.name}
					onChange={handleInputChange}
					required
				/>
				<div className="image-preview">
					{/* Image preview will be displayed here */}
				</div>
				<label htmlFor="media">Media (URL):</label>
				<input
					type="text"
					id="media"
					name="media"
					value={formData.media}
					onChange={handleInputChange}
				/>
			</div>
			<div className="description">
				<label htmlFor="description">Description:</label>
				<textarea
					id="description"
					name="description"
					value={formData.description}
					onChange={handleInputChange}
					required
				></textarea>
			</div>
			<div className="max-guests">
				<label htmlFor="maxGuests">Maximum Guests:</label>
				<input
					type="number"
					id="maxGuests"
					name="maxGuests"
					value={formData.maxGuests}
					onChange={handleInputChange}
					required
				/>
			</div>
			<div className="form-group">
            <label>Facilities:</label>
            <hr />
				<div className="facilities">
				
					<label htmlFor="wifi">Wifi:</label>
					<input
						type="checkbox"
						id="wifi"
						name="wifi"
						checked={formData.meta.wifi}
						onChange={handleInputChange}
					/>
					<label htmlFor="parking">Parking:</label>
					<input
						type="checkbox"
						id="parking"
						name="parking"
						checked={formData.meta.parking}
						onChange={handleInputChange}
					/>
					<label htmlFor="breakfast">Breakfast:</label>
					<input
						type="checkbox"
						id="breakfast"
						name="breakfast"
						checked={formData.meta.breakfast}
						onChange={handleInputChange}
					/>
					<label htmlFor="pets">Pets:</label>
					<input
						type="checkbox"
						id="pets"
						name="pets"
						checked={formData.meta.pets}
						onChange={handleInputChange}
					/>
				</div>
			</div>
			<button type="submit">Create Venue</button>
		</form>
	);
};

export default CreateVenueForm;
