// CreateVenueForm.jsx

import React, { useState } from 'react';

import './createvenueform.css';

function CreateVenueForm() {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    media: [],
    price: 0,
    maxGuests: 0,
    rating: 0,
    meta: {
      wifi: false,
      parking: false,
      breakfast: false,
      pets: false
    },
    location: {
      address: "",
      city: "",
      zip: "",
      country: "",
      continent: "",
      lat: 0,
      lng: 0
    }
  });

  const handleNext = () => {
    setStep(step + 1);
  };

  const handlePrevious = () => {
    setStep(step - 1);
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    const updatedData = name.includes('.')  // Check for nested properties
      ? {
          ...formData,
          [name]: type === 'checkbox' ? checked : value,
        }
      : {
          ...formData,
          [name]: type === 'checkbox' ? checked : value,
        };
    setFormData(updatedData);
  };

  const handleSubmit = () => {
    // Handle form submission
    console.log(formData);
  };

  switch (step) {
    case 1:
      return (
        <div className='create-venue-form'>
          <h2>Primary Info</h2>
          <input type="text" name="name" value={formData.name} onChange={handleChange} placeholder="Venue Name" />
          <input type="text" name="description" value={formData.description} onChange={handleChange} placeholder="Description" />
          {/* Other input fields for media, price, etc. */}
          <button onClick={handleNext}>Next</button>
        </div>
      );
    case 2:
      return (
        <div className='create-venue-form'>
          <h2>Location Data</h2>
          <input type="text" name="country" value={formData.location.country} onChange={handleChange} placeholder="Country" />
          <input type="text" name="city" value={formData.location.city} onChange={handleChange} placeholder="City" />
          {/* Other input fields for address, zip, etc. */}
          <button onClick={handlePrevious}>Previous</button>
          <button onClick={handleNext}>Next</button>
        </div>
      );
    case 3:
      return (
        <div className='create-venue-form'>
            <h2>Facilities</h2>
            <label>
              <input type="checkbox" name="wifi" checked={formData.meta.wifi} onChange={handleChange} /> Wifi
            </label>
            <label>
              <input type="checkbox" name="parking" checked={formData.meta.parking} onChange={handleChange} /> Parking
            </label>
            {/* Other input fields for pets, breakfast, etc. */}
            <button onClick={handlePrevious}>Previous</button>
            <button onClick={handleSubmit}>Submit</button>

        </div>
      );
    default:
      return null;
  }
}

export default CreateVenueForm;