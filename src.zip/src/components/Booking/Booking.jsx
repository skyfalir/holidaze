import React, { useState } from 'react';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

const bookedDates = [
  new Date('2024-02-25'),
  new Date('2024-12-26'),
  new Date('2024-12-27')
  // Add other booked dates as needed
];

const Booking = ({ venue }) => {
  const [isBookingVisible, setIsBookingVisible] = useState(true);
  const [formData, setFormData] = useState({
    dateFrom: new Date(),
    dateTo: new Date(),
    guests: 0,
    venueId: venue.id
  });

  const toggleBookingVisibility = () => {
    setIsBookingVisible(!isBookingVisible);
  };

  const handleDateFromChange = date => {
    setFormData({ ...formData, dateFrom: date });
  };

  const handleDateToChange = date => {
    setFormData({ ...formData, dateTo: date });
  };

  const handleGuestsChange = event => {
    setFormData({ ...formData, guests: event.target.value });
  };

  const handleSubmit = event => {
    event.preventDefault();
    // Handle form submission with the formData
    console.log('Form submitted:', formData);
  };

  return (
    <div>
      <button onClick={toggleBookingVisibility}>
        {isBookingVisible ? 'Hide Booking' : 'Show Booking'}
      </button>
      {isBookingVisible && (
        <div className="booking-container">
          <h2>Booking Details for {venue.name}</h2>
          <form onSubmit={handleSubmit}>
            <div>
              <label>Date From:</label>
              <DatePicker
                selected={formData.dateFrom}
                onChange={handleDateFromChange}
                highlightDates={bookedDates}
              />
            </div>
            <div>
              <label>Date To:</label>
              <DatePicker
                selected={formData.dateTo}
                onChange={handleDateToChange}
                highlightDates={bookedDates}
              />
            </div>
            <div>
              <label>Guests:</label>
              <input type="number" value={formData.guests} onChange={handleGuestsChange} />
            </div>
            <button type="submit">Submit</button>
          </form>
        </div>
      )}
    </div>
  );
};

export default Booking;