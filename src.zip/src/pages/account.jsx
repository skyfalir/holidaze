import React from 'react';
import { useState } from 'react';

import './account.css';
import handlelocalStorage from '../utility/localStorageHandling';
import { avatarUpdate } from '../utility/api/updateAvatar';



const Account = () => {
  // Other state and logic

  const [avatarUrl, setAvatarUrl] = useState('');
  const [error, setError] = useState('');

  const isValidUrl = (url) => {
    const urlPattern = /^(ftp|http|https):\/\/[^ "]+$/;
    return urlPattern.test(url);
  };

  const handleAvatarUpdate = async (e) => {
    e.preventDefault();

    if (!isValidUrl(avatarUrl)) {
      setError('Please enter a valid URL');
      return;
    }

    try {
      await avatarUpdate(avatarUrl);
      // Handle success
    } catch (error) {
      setError('An error occurred while updating the avatar');
      console.error('Error updating avatar:', error);
    }
  };


	return (
		<div className="account-wrapper">
			<div className="account-container">
				<div className="settings-sidebar">
					<ul className="setting-list">
						<li>Account</li>
						<li>Notifications</li>
						<li>Cookies</li>
						{/* Add more list items here */}
					</ul>
				</div>
				<div className="settings">
					<div className="user-info">
						<p>{handlelocalStorage.getUserData().name}</p>
						<p>{handlelocalStorage.getUserData().email}</p>
					</div>
					<button className="change-password">Change Password</button>
					<div className="avatar-container">
						<img
							src={handlelocalStorage.getAvatarUrl()}
							alt="avatar"
							className="avatar-preview"
						/>
             <div className="error-message">{error}</div>
						<form
							className="change-avatar-form"
							onSubmit={handleAvatarUpdate}
						>
							<input
								type="text"
								id="avatarUrl"
								name="avatar"
								placeholder="Enter new avatar URL"
                value={avatarUrl}  // Set the value of the input field to the avatarUrl state
                onChange={(e) => setAvatarUrl(e.target.value)}
							/>
							<button type="submit">Update Avatar</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	);
};

export default Account;
