import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import VenueCard from '../components/Venue-Card/Venue-Card';
import './venues.css';
import getVenueData from '../utility/api/fetchVenueData';
import VenueFilter from '../components/VenueFilter/VenueFilter';


const Venues = () => {
	const [venueData, setVenueData] = useState([]);
	const [filters, setFilters] = useState({ sortOrder: 'asc', sortField: 'name' }); // State to hold the filter values

	const handleFilterChange = (newFilters) => {
		setFilters(newFilters); // Update the filters when the filter values change
	};

	useEffect(() => {
		const fetchData = async () => {
			try {
				const data = await getVenueData('', filters); // Pass the filters to getVenueData
				if (Array.isArray(data)) {
					setVenueData(data);
				} else {
					console.error('venueData is not an array:', data);
				}
			} catch (error) {
				console.error('Error fetching venue data:', error);
			}
		};

		fetchData();
	}, [filters]); // Include filters as a dependency


	return (
		<div>
			<Helmet>
				<title>HoliDaze | Venues</title>
			</Helmet>
			<div className="top-section">
				<p>Find your Venue</p>
				<VenueFilter onFilterChange={handleFilterChange} />
			</div>
			<Link to="/venue/create">Create Venue</Link>
			<div className="row">
				<div className="venues">
					<h1>Our Venues</h1>
					<div className="venue-cards-container">
						{venueData.map((venue) => (
							<VenueCard
								key={venue.id} // Important
								venue={venue}
							/>
						))}
					</div>
				</div>
			</div>
		</div>
	);
};
export default Venues;
