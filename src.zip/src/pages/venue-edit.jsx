import React from 'react';
import CreateVenueForm from '../components/CreateVenue/CreateVenue-copy';
/* import EditVenue from './EditVenue'; */

function VenueFormPage({ mode }) {
  return (
    <div>
      {mode === 'create' && <CreateVenueForm />}
      {/* {mode === 'edit' && <EditVenue />} */}
    </div>
  );
}

export default VenueFormPage;