import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useParams } from 'react-router-dom';
import getVenueData from '../utility/api/fetchVenueData'; // Assuming you have a function to fetch a venue by ID
import './venue.css';
import Booking from '../components/Booking/Booking';
import { Carousel } from 'react-responsive-carousel';
import 'react-responsive-carousel/lib/styles/carousel.min.css';
import MapComponent from '../components/MapComponent/Map';

const Venue = () => {
	const { id } = useParams(); // Access the id parameter from the URL
	const [venue, setVenue] = useState(null);

	useEffect(() => {
		const fetchVenue = async () => {
			try {
				const data = await getVenueData(id); // Fetch the venue data by ID
				setVenue(data);
			} catch (error) {
				console.error('Error fetching venue data:', error);
			}
		};

		fetchVenue();
	}, [id]);

	if (!venue) {
		return <div>Loading...</div>; // or handle the loading state as needed
	}

	return (
		<div className="venue-container">
			<Helmet>
				<title>Holidaze | {venue.name}</title>
			</Helmet>
			<div className="venue-header">
				<h1>{venue.name}</h1>
				{venue.media.length > 0 && (
					<Carousel showArrows={true} showThumbs={true}>
						{venue.media.map((mediaItem, index) => (
							<div key={index}>
								<img src={mediaItem} alt={`Slide ${index + 1}`} />
							</div>
						))}
					</Carousel>
				)}
			</div>
			<div className="venue-details">
				<h2>Description:</h2>
				<p>{venue.description}</p>
				<div className="venue-meta">
					<p>Price: {venue.price}</p>
					<p>Max Guests: {venue.maxGuests}</p>
					<p>Rating: {venue.rating}</p>
				</div>
			</div>
			<div className="venue-location">
				<p>
					Location: {venue.location.city}, {venue.location.country}
				</p>
				<MapComponent venue={venue} />
			</div>
			<Booking venue={venue} />
		</div>
	);
};

export default Venue;
